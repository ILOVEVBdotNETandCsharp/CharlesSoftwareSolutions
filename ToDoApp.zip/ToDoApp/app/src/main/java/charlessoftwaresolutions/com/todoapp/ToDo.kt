package charlessoftwaresolutions.com.todoapp

import android.os.Parcelable
import android.os.Parcel

/**
 * Created by ComputerLab on 6/26/2017.
 */
class Todo() : Parcelable
{
    var title:String? = null
    var summary:String? = null

    constructor(title:String,summary:String) : this()
    {
        this.title = title
        this.summary = summary
    }

    override  fun writeToParcel(parcel:Parcel, flags: Int)
    {
        parcel.writeString(this.title)
        parcel.writeString(this.summary)

    }

    constructor(parcel:Parcel) : this()
    {
        this.title = parcel.readString()
        this.summary = parcel.readString()
    }

    companion object
    {
        @JvmField val CREATOR: Parcelable.Creator<Todo> = object : Parcelable.Creator<Todo>
        {
            override fun createFromParcel(source: Parcel): Todo = Todo(source)

            override fun newArray(size: Int): Array<Todo?> = arrayOfNulls(size)
        }
    }

    override fun describeContents() = 0

}