package charlessoftwaresolutions.com.todoapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class ToDoActivity : AppCompatActivity()
{

    var todoList:MutableList<Todo> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_to_do)

        prepareDummyData()
    }

    fun prepareDummyData()
    {
        //TODO("Replace with real data")

        todoList.add(Todo("title", "summary"))
        todoList.add(Todo("title", "summary"))
        todoList.add(Todo("title", "summary"))
        todoList.add(Todo("title", "summary"))
        todoList.add(Todo("title", "summary"))
    }
}
